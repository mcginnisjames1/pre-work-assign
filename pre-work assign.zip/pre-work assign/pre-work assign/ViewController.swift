//
//  ViewController.swift
//  pre-work assign
//
//  Created by cs_pple_02 on 1/22/21.
//  Copyright © 2021 cs_pple_02. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var BillAmount: UILabel!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var totalLable: UITextField!
    @IBOutlet weak var billAmountTXT: UITextField!
    @IBOutlet weak var tipControl: UISegmentedControl!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func tipCalculation(_ sender: Any) {
        // Get bill amount from text field input
               let bill = Double(billAmountTXT.text!) ?? 0
               
               // Get Total tip by multiplying tip * tipPercentage
               let tipPercentages = [0.15, 0.18, 0.2]
               let tip = bill *
                   tipPercentages[tipControl.selectedSegmentIndex]
               let total = bill + tip
               
               // Updaet Tip Amount Label
               tipAmountLabel.text = String(format: "$%.2f", tip)
               // Update Total Amount
               totalLable.text = String(format: "$%.2f", total)
    }
    
    


}
